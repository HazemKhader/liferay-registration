(function () {
  const root = document.getElementById("registration-requests-root");
  const prevBtn = document.getElementById("prev-page");
  const nextBtn = document.getElementById("next-page");
  const pageInfo = document.getElementById("page-info");

  const portalURL = Liferay.ThemeDisplay.getPortalURL();
  const pathContext = Liferay.ThemeDisplay.getPathContext();
  const baseO = `${portalURL}${pathContext}/o`;
  const objectBase = `${baseO}/c/registrationrequests`;
  const wfBase = `${baseO}/headless-admin-workflow/v1.0`;

  let currentPage = 1;
  const pageSize = 10;

  async function fetchJSON(url, options = {}) {
    const res = await fetch(url, {
      credentials: "include",
      headers: {
        Accept: "application/json",
        ...(options.method && options.method !== "GET"
          ? { "Content-Type": "application/json" }
          : {}),
        "x-csrf-token": Liferay.authToken,
      },
      ...options,
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`${res.status} ${res.statusText}: ${txt}`);
    }
    return res.json();
  }

  async function fetchPendingTasks() {
    const userId = Liferay.ThemeDisplay.getUserId();

    const [meResp, rolesResp] = await Promise.all([
      fetchJSON(`${wfBase}/workflow-tasks/assigned-to-me`),
      fetchJSON(
        `${wfBase}/workflow-tasks/assigned-to-user-roles?assigneeId=${userId}`
      ),
    ]);

    const combined = [...(meResp.items || []), ...(rolesResp.items || [])];
    const unique = Object.values(
      combined.reduce((map, t) => {
        map[t.id] = t;
        return map;
      }, {})
    );

    // keep only open tasks for RegistrationRequest
    return unique.filter(
      (t) =>
        t.completed === false &&
        t.objectReviewed?.assetType === "RegistrationRequest"
    );
  }

  async function loadPage(page) {
    root.innerHTML = '<div class="loading">Loading pending requests…</div>';
    currentPage = page;

    try {
      const objResp = await fetchJSON(
        `${objectBase}` +
          `?filter=(status/any(x:(x eq 1)))` +
          `&page=${page}&pageSize=${pageSize}` +
          `&sort=dateCreated:desc`
      );
      const { items: entries = [], page: p, lastPage } = objResp;

      const tasks = await fetchPendingTasks();
      const taskMap = tasks.reduce((m, t) => {
        m[t.objectReviewed.id] = t;
        return m;
      }, {});

      if (!entries.length) {
        root.innerHTML = "<div>No pending requests.</div>";
      } else {
        root.innerHTML = entries
          .map((entry) => {
            const task = taskMap[entry.id];
            const disable = task ? "" : "disabled";
            const href = task?.actions?.changeTransition?.href;

            return `
              <div class="card registration-card" data-task-id="${
                task?.id || ""
              }">
              <h4>
                <span class="highlight">
                  ${entry.firstName} ${entry.lastName}
                </span>
              </h4>

              <p>
                <strong>Document Type:</strong>
                <span class="highlight">
                  ${entry.documentType?.name || "-"}
                </span>
              </p>

              <p>
                <strong>Document ID:</strong>
                <span class="highlight">
                  ${entry.documentId || "-"}
                </span>
              </p>

              <p>
                <strong>Uploaded:</strong>
                <span class="highlight">
                  ${new Date(entry.dateCreated).toLocaleString()}
                </span>
              </p>

              <div class="actions">
                <button data-action="approve" data-href="${href || ""}" ${disable}>
                  Approve
                </button>
                <button data-action="reject" data-href="${href || ""}" ${disable}>
                  Reject
                </button>
              </div>
            </div>
            `;
          })
          .join("");
      }

      pageInfo.textContent = `Page ${p} of ${lastPage}`;
      prevBtn.disabled = p <= 1;
      nextBtn.disabled = p >= lastPage;
    } catch (err) {
      console.error(err);
      root.innerHTML = `<div class="alert alert-danger">Error: ${err.message}</div>`;
    }
  }

  root.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;

    const action = btn.dataset.action;
    const href = btn.dataset.href;
    const card = btn.closest(".card");
    const taskId = card.dataset.taskId;
    if (!href) return;

    btn.disabled = true;
    btn.textContent = "Processing…";

    try {
      await fetchJSON(`${wfBase}/workflow-tasks/${taskId}/assign-to-me`, {
        method: "POST",
        body: JSON.stringify({
          workflowTaskId: Number(taskId),
          dueDate: new Date().toISOString(),
          comment: "",
        }),
      });

      await fetchJSON(href, {
        method: "POST",
        body: JSON.stringify({
          workflowTaskId: Number(taskId),
          transitionName: action,
          comment: "",
        }),
      });

      Liferay.Util.openToast({
        message: `Request ${action}d!`,
        type: "success",
      });

      card.remove();
      if (!root.querySelector(".card")) {
        root.innerHTML = "<div>No pending requests.</div>";
      }
    } catch (err) {
      console.error(err);
      Liferay.Util.openToast({
        message: `Action failed: ${err.message}`,
        type: "danger",
      });
      btn.disabled = false;
      btn.textContent = action[0].toUpperCase() + action.slice(1);
    }
  });

  prevBtn.addEventListener("click", () => loadPage(currentPage - 1));
  nextBtn.addEventListener("click", () => loadPage(currentPage + 1));

  // initial load
  loadPage(1);
})();